from django import template

register = template.Library()

@register.filter
def split(value, delimiter=','):
    return value.split(delimiter)

@register.filter
def dict_get(d, key):
    if d and key in d:
        obj = d[key]
        if hasattr(obj, 'Box_Office_Collection'):
            return obj.Box_Office_Collection or ''
        if hasattr(obj, 'No_of_Seasons'):
            return obj.No_of_Seasons or ''
    return ''

@register.filter
def dict_get_list(d, key):
    if d and key in d:
        return d[key]
    return []
