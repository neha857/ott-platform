from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.db import connection
from .models import (Login, User, Content, Movie, Series, Episode,
                     Actor, ActsIn, Director, Directs, SubPlan, Payment, Watches)


# ─── Helpers ────────────────────────────────────────────────────────────────

def login_required_user(view_func):
    def wrapper(request, *args, **kwargs):
        if request.session.get('role') != 'user':
            return redirect('login')
        return view_func(request, *args, **kwargs)
    return wrapper


def subscription_required(view_func):
    def wrapper(request, *args, **kwargs):
        if request.session.get('role') != 'user':
            return redirect('login')
        user_id = request.session.get('user_id')
        if user_id and not has_active_subscription(user_id):
            return redirect('user_plans')
        return view_func(request, *args, **kwargs)
    return wrapper


def login_required_admin(view_func):
    def wrapper(request, *args, **kwargs):
        if request.session.get('role') != 'admin':
            return redirect('login')
        return view_func(request, *args, **kwargs)
    return wrapper


def next_id(model, pk_field):
    return (model.objects.order_by(f'-{pk_field}').values_list(pk_field, flat=True).first() or 0) + 1


def parse_duration_days(duration_str):
    """Convert plan Duration string (e.g. '30 days', '1 Month', '3 Months', '1 Year') to integer days."""
    import re
    if not duration_str:
        return None
    s = duration_str.strip().lower()
    m = re.match(r'(\d+)\s*(day|days)', s)
    if m:
        return int(m.group(1))
    m = re.match(r'(\d+)\s*(month|months)', s)
    if m:
        return int(m.group(1)) * 30
    m = re.match(r'(\d+)\s*(year|years)', s)
    if m:
        return int(m.group(1)) * 365
    return None


def has_active_subscription(user_id):
    """Return True if the user has at least one non-expired Success payment."""
    from datetime import date, timedelta
    payments = Payment.objects.filter(User_id=user_id, Status='Success').select_related('Plan')
    today = date.today()
    for p in payments:
        if not p.Date or not p.Plan or not p.Plan.Duration:
            continue
        days = parse_duration_days(p.Plan.Duration)
        if days and (p.Date + timedelta(days=days)) >= today:
            return True
    return False


# ─── Auth ────────────────────────────────────────────────────────────────────

def login_view(request):
    if request.session.get('role') == 'admin':
        return redirect('admin_dashboard')
    if request.session.get('role') == 'user':
        return redirect('user_home')
    error = None
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()
        mode = request.POST.get('mode', 'user')
        try:
            login_obj = Login.objects.get(Username=username, Password=password, Role=mode)
            request.session['username'] = username
            request.session['role'] = login_obj.Role
            request.session['login_id'] = login_obj.Login_ID
            if login_obj.User_id:
                request.session['user_id'] = login_obj.User_id
            
            # ── Subscription check for regular users ──────────────────────────
            if mode == 'user' and login_obj.User_id:
                if not has_active_subscription(login_obj.User_id):
                    return redirect('user_plans')
            # ─────────────────────────────────────────────────────────────────
            return redirect('admin_dashboard' if mode == 'admin' else 'user_home')
        except Login.DoesNotExist:
            error = 'Invalid credentials. Please try again.'
    return render(request, 'ott_app/login.html', {'error': error})


def logout_view(request):
    request.session.flush()
    return redirect('login')


def signup_view(request):
    if request.session.get('role'):
        return redirect('user_home')
    error = None
    success = None
    if request.method == 'POST':
        name     = request.POST.get('name', '').strip()
        email    = request.POST.get('email', '').strip()
        phone    = request.POST.get('phone', '').strip()
        country  = request.POST.get('country', '').strip()
        dob      = request.POST.get('dob', '').strip()
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()
        confirm  = request.POST.get('confirm_password', '').strip()
        if not all([name, email, username, password, confirm]):
            error = 'Please fill in all required fields.'
        elif password != confirm:
            error = 'Passwords do not match.'
        elif len(password) < 4:
            error = 'Password must be at least 4 characters.'
        elif Login.objects.filter(Username=username).exists():
            error = f'Username "{username}" is already taken.'
        elif User.objects.filter(Email=email).exists():
            error = 'An account with this email already exists.'
        else:
            try:
                uid = next_id(User, 'User_ID')
                lid = next_id(Login, 'Login_ID')
                with connection.cursor() as c:
                    c.execute("INSERT INTO `user` (User_ID,Name,Email,Phone,Country,DOB) VALUES (%s,%s,%s,%s,%s,%s)",
                              [uid, name, email, phone or None, country or None, dob or None])
                    c.execute("INSERT INTO `login` (Login_ID,User_ID,Username,Password,Role) VALUES (%s,%s,%s,%s,%s)",
                              [lid, uid, username, password, 'user'])
                success = f'Account created! You can now sign in as "{username}".'
            except Exception as e:
                error = f'Registration failed: {str(e)}'
    return render(request, 'ott_app/signup.html', {'error': error, 'success': success})


# ─── USER VIEWS ──────────────────────────────────────────────────────────────

@subscription_required
def user_home(request):
    contents = Content.objects.all()
    movies = list(Movie.objects.values_list('Content_id', flat=True))
    series_ids = list(Series.objects.values_list('Content_id', flat=True))
    return render(request, 'ott_app/user_home.html', {
        'contents': contents, 'movies': movies, 'series_ids': series_ids,
        'username': request.session.get('username'),
    })


@subscription_required
def user_browse(request):
    filter_type = request.GET.get('type', 'all')
    query = request.GET.get('q', '').strip()
    movies = list(Movie.objects.values_list('Content_id', flat=True))
    series_ids = list(Series.objects.values_list('Content_id', flat=True))
    contents = Content.objects.all()
    if filter_type == 'movie':
        contents = contents.filter(Content_ID__in=movies)
    elif filter_type == 'series':
        contents = contents.filter(Content_ID__in=series_ids)
    if query:
        contents = contents.filter(Title__icontains=query)
    return render(request, 'ott_app/user_browse.html', {
        'contents': contents, 'movies': movies, 'series_ids': series_ids,
        'filter_type': filter_type, 'query': query,
        'username': request.session.get('username'),
    })


@subscription_required
def search_suggestions(request):
    """Return up to 8 title suggestions matching the query string as JSON."""
    q = request.GET.get('q', '').strip()
    results = []
    if q:
        matches = Content.objects.filter(Title__icontains=q).values('Content_ID', 'Title', 'Rating', 'Release_Year')[:8]
        movies_set = set(Movie.objects.values_list('Content_id', flat=True))
        for m in matches:
            ctype = 'Movie' if m['Content_ID'] in movies_set else 'Series'
            results.append({
                'id': m['Content_ID'],
                'title': m['Title'],
                'rating': float(m['Rating']) if m['Rating'] else None,
                'year': m['Release_Year'],
                'type': ctype,
            })
    return JsonResponse({'results': results})


@subscription_required
def content_detail(request, content_id):
    try:
        content = Content.objects.get(Content_ID=content_id)
    except Content.DoesNotExist:
        return redirect('user_home')
    movies = list(Movie.objects.values_list('Content_id', flat=True))
    series_ids = list(Series.objects.values_list('Content_id', flat=True))
    is_movie = content_id in movies
    is_series = content_id in series_ids
    movie_obj = series_obj = None
    episodes = []
    if is_movie:
        movie_obj = Movie.objects.filter(Content_id=content_id).first()
    if is_series:
        series_obj = Series.objects.filter(Content_id=content_id).first()
        if series_obj:
            episodes = Episode.objects.filter(Content_id=content_id).order_by('Season_No', 'Episode_ID')
    # Use raw SQL to avoid ORM 'id' issue on junction tables
    with connection.cursor() as c:
        c.execute("SELECT Actor_ID FROM acts_in WHERE Content_ID=%s", [content_id])
        actor_ids = [r[0] for r in c.fetchall()]
        c.execute("SELECT Director_ID FROM directs WHERE Content_ID=%s", [content_id])
        director_ids = [r[0] for r in c.fetchall()]
    actors = Actor.objects.filter(Actor_ID__in=actor_ids)
    directors = Director.objects.filter(Director_ID__in=director_ids)
    return render(request, 'ott_app/content_detail.html', {
        'content': content, 'is_movie': is_movie, 'is_series': is_series,
        'movie_obj': movie_obj, 'series_obj': series_obj, 'episodes': episodes,
        'actors': actors, 'directors': directors,
        'username': request.session.get('username'),
    })


@login_required_user
def user_profile(request):
    from datetime import date, timedelta

    user_id = request.session.get('user_id')
    user = watched = None
    payment_data = []
    expiry_warnings = []


    if user_id:
        user = User.objects.filter(User_ID=user_id).first()
        payments = Payment.objects.filter(User_id=user_id).select_related('Plan').order_by('-Date')
        today = date.today()

        for p in payments:
            start = p.Date
            end = None
            days_left = None
            if start and p.Plan and p.Plan.Duration:
                days = parse_duration_days(p.Plan.Duration)
                if days:
                    end = start + timedelta(days=days)
                    days_left = (end - today).days

            entry = {
                'payment': p,
                'start_date': start,
                'end_date': end,
                'days_left': days_left,
            }
            payment_data.append(entry)

            # Warn if active plan expires within 7 days
            if p.Status == 'Success' and days_left is not None and 0 <= days_left <= 7:
                expiry_warnings.append({
                    'plan_name': p.Plan.Plan_Name if p.Plan else 'Your plan',
                    'end_date': end,
                    'days_left': days_left,
                })

        with connection.cursor() as c:
            c.execute("SELECT Content_ID FROM watches WHERE User_ID=%s", [user_id])
            watched_ids = [r[0] for r in c.fetchall()]
        watched = Content.objects.filter(Content_ID__in=watched_ids)

    msg = request.session.pop('msg', None)
    msg_type = request.session.pop('msg_type', 'success')

    return render(request, 'ott_app/user_profile.html', {
        'user': user, 'payment_data': payment_data, 'watched': watched,
        'expiry_warnings': expiry_warnings,
        'username': request.session.get('username'),
        'msg': msg, 'msg_type': msg_type,
    })



@login_required_user
def user_plans(request):
    plans = SubPlan.objects.all()
    return render(request, 'ott_app/user_plans.html', {
        'plans': plans, 'username': request.session.get('username'),
    })


@login_required_user
def subscribe_plan(request):
    if request.method == 'POST':
        plan_id = request.POST.get('plan_id')
        user_id = request.session.get('user_id')
        if not user_id or not plan_id:
            return redirect('user_plans')
        
        try:
            plan = SubPlan.objects.get(Plan_ID=plan_id)
            user = User.objects.get(User_ID=user_id)
            
            from datetime import date
            pid = next_id(Payment, 'Payment_ID')
            with connection.cursor() as c:
                c.execute(
                    "INSERT INTO `payment` (Payment_ID, User_ID, Plan_ID, Amount, Date, Method, Status) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                    [pid, user.User_ID, plan.Plan_ID, plan.Price, date.today(), 'Credit Card', 'Success']
                )
            
            request.session['msg'] = f'Successfully subscribed to {plan.Plan_Name} plan!'
            request.session['msg_type'] = 'success'
            return redirect('user_profile')
        except Exception as e:
            request.session['msg'] = f'Subscription failed: {str(e)}'
            request.session['msg_type'] = 'error'
            return redirect('user_plans')
    
    return redirect('user_plans')


# ─── ADMIN DASHBOARD ─────────────────────────────────────────────────────────

@login_required_admin
def admin_dashboard(request):
    stats = {
        'users': User.objects.count(),
        'content': Content.objects.count(),
        'movies': Movie.objects.count(),
        'series': Series.objects.count(),
        'payments': Payment.objects.count(),
        'revenue': sum(p.Amount for p in Payment.objects.filter(Status='Success') if p.Amount),
    }
    recent_payments = Payment.objects.select_related('User', 'Plan').order_by('-Date')[:5]
    return render(request, 'ott_app/admin_dashboard.html', {
        'stats': stats, 'recent_payments': recent_payments,
    })


# ─── ADMIN: CONTENT CRUD ─────────────────────────────────────────────────────

@login_required_admin
def admin_content(request):
    msg = request.session.pop('msg', None)
    msg_type = request.session.pop('msg_type', 'success')
    contents = Content.objects.all().order_by('-Content_ID')
    movies = list(Movie.objects.values_list('Content_id', flat=True))
    series_ids = list(Series.objects.values_list('Content_id', flat=True))
    movie_objs = {m.Content_id: m for m in Movie.objects.all()}
    series_objs = {s.Content_id: s for s in Series.objects.all()}
    actors = Actor.objects.all().order_by('Name')
    directors = Director.objects.all().order_by('Name')

    # Use raw SQL to avoid ORM looking for non-existent 'id' column
    content_actors = {}
    content_directors = {}
    with connection.cursor() as c:
        c.execute("SELECT Content_ID, Actor_ID FROM acts_in")
        for row in c.fetchall():
            content_actors.setdefault(row[0], []).append(row[1])
        c.execute("SELECT Content_ID, Director_ID FROM directs")
        for row in c.fetchall():
            content_directors.setdefault(row[0], []).append(row[1])

    return render(request, 'ott_app/admin_content.html', {
        'contents': contents, 'movies': movies, 'series_ids': series_ids,
        'movie_objs': movie_objs, 'series_objs': series_objs,
        'actors': actors, 'directors': directors,
        'content_actors': content_actors, 'content_directors': content_directors,
        'msg': msg, 'msg_type': msg_type,
    })


@login_required_admin
def admin_content_add(request):
    if request.method != 'POST':
        return redirect('admin_content')
    try:
        title       = request.POST.get('title', '').strip()
        duration    = request.POST.get('duration', '').strip()
        country     = request.POST.get('release_country', '').strip()
        year        = request.POST.get('release_year', '')
        rating      = request.POST.get('rating', '')
        ctype       = request.POST.get('content_type', 'movie')
        box_off     = request.POST.get('box_office', '').strip()
        seasons     = request.POST.get('seasons', '1')
        actor_ids   = request.POST.getlist('actor_ids')
        director_ids = request.POST.getlist('director_ids')
        if not title:
            raise ValueError('Title is required.')
        cid = next_id(Content, 'Content_ID')
        with connection.cursor() as c:
            c.execute(
                "INSERT INTO `content` (Content_ID,Title,Duration,Release_Country,Release_Year,Rating) VALUES (%s,%s,%s,%s,%s,%s)",
                [cid, title, duration or None, country or None,
                 int(year) if year else None, float(rating) if rating else None]
            )
            if ctype == 'movie':
                c.execute("INSERT INTO `movie` (Content_ID,Box_Office_Collection) VALUES (%s,%s)",
                          [cid, box_off or None])
            else:
                c.execute("INSERT INTO `series` (Content_ID,No_of_Seasons) VALUES (%s,%s)",
                          [cid, int(seasons) if seasons else 1])
            for aid in actor_ids:
                if aid:
                    c.execute("INSERT IGNORE INTO `acts_in` (Content_ID,Actor_ID) VALUES (%s,%s)", [cid, int(aid)])
            for did in director_ids:
                if did:
                    c.execute("INSERT IGNORE INTO `directs` (Content_ID,Director_ID) VALUES (%s,%s)", [cid, int(did)])
        request.session['msg'] = f'"{title}" added successfully!'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_content')


@login_required_admin
def admin_content_edit(request, content_id):
    if request.method != 'POST':
        return redirect('admin_content')
    try:
        title    = request.POST.get('title', '').strip()
        duration = request.POST.get('duration', '').strip()
        country  = request.POST.get('release_country', '').strip()
        year     = request.POST.get('release_year', '')
        rating   = request.POST.get('rating', '')
        box_off  = request.POST.get('box_office', '').strip()
        seasons  = request.POST.get('seasons', '')
        with connection.cursor() as c:
            c.execute(
                "UPDATE `content` SET Title=%s,Duration=%s,Release_Country=%s,Release_Year=%s,Rating=%s WHERE Content_ID=%s",
                [title, duration or None, country or None,
                 int(year) if year else None, float(rating) if rating else None, content_id]
            )
            if Movie.objects.filter(Content_id=content_id).exists():
                c.execute("UPDATE `movie` SET Box_Office_Collection=%s WHERE Content_ID=%s",
                          [box_off or None, content_id])
            if Series.objects.filter(Content_id=content_id).exists():
                c.execute("UPDATE `series` SET No_of_Seasons=%s WHERE Content_ID=%s",
                          [int(seasons) if seasons else None, content_id])
        request.session['msg'] = f'"{title}" updated successfully!'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Update error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_content')


@login_required_admin
def admin_content_delete(request, content_id):
    if request.method != 'POST':
        return redirect('admin_content')
    try:
        content = Content.objects.get(Content_ID=content_id)
        title = content.Title
        with connection.cursor() as c:
            c.execute("DELETE FROM `episode` WHERE Content_ID=%s", [content_id])
            c.execute("DELETE FROM `acts_in` WHERE Content_ID=%s", [content_id])
            c.execute("DELETE FROM `directs` WHERE Content_ID=%s", [content_id])
            c.execute("DELETE FROM `watches` WHERE Content_ID=%s", [content_id])
            c.execute("DELETE FROM `movie` WHERE Content_ID=%s", [content_id])
            c.execute("DELETE FROM `series` WHERE Content_ID=%s", [content_id])
            c.execute("DELETE FROM `content` WHERE Content_ID=%s", [content_id])
        request.session['msg'] = f'"{title}" deleted.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Delete error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_content')


# ─── ADMIN: EPISODE CRUD ─────────────────────────────────────────────────────

@login_required_admin
def admin_episodes(request, content_id):
    msg = request.session.pop('msg', None)
    msg_type = request.session.pop('msg_type', 'success')
    content = Content.objects.filter(Content_ID=content_id).first()
    episodes = Episode.objects.filter(Content_id=content_id).order_by('Season_No', 'Episode_ID')
    return render(request, 'ott_app/admin_episodes.html', {
        'content': content, 'episodes': episodes,
        'msg': msg, 'msg_type': msg_type,
    })


@login_required_admin
def admin_episode_add(request, content_id):
    if request.method != 'POST':
        return redirect('admin_episodes', content_id=content_id)
    try:
        season   = int(request.POST.get('season_no', 1))
        title    = request.POST.get('title', '').strip()
        duration = request.POST.get('duration', '').strip()
        rel_date = request.POST.get('release_date', '').strip()
        eid = next_id(Episode, 'Episode_ID')
        with connection.cursor() as c:
            c.execute(
                "INSERT INTO `episode` (Episode_ID,Content_ID,Season_No,Title,Duration,Release_Date) VALUES (%s,%s,%s,%s,%s,%s)",
                [eid, content_id, season, title or None, duration or None, rel_date or None]
            )
        request.session['msg'] = 'Episode added.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_episodes', content_id=content_id)


@login_required_admin
def admin_episode_delete(request, episode_id):
    if request.method != 'POST':
        return redirect('admin_content')
    cid = request.POST.get('content_id')
    try:
        with connection.cursor() as c:
            c.execute("DELETE FROM `episode` WHERE Episode_ID=%s", [episode_id])
        request.session['msg'] = 'Episode deleted.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_episodes', content_id=cid)


# ─── ADMIN: ACTOR CRUD ───────────────────────────────────────────────────────

@login_required_admin
def admin_actors(request):
    msg = request.session.pop('msg', None)
    msg_type = request.session.pop('msg_type', 'success')
    actors = Actor.objects.all().order_by('Name')
    return render(request, 'ott_app/admin_actors.html', {
        'actors': actors, 'msg': msg, 'msg_type': msg_type,
    })


@login_required_admin
def admin_actor_add(request):
    if request.method != 'POST':
        return redirect('admin_actors')
    try:
        name = request.POST.get('name', '').strip()
        dob  = request.POST.get('dob', '').strip()
        if not name:
            raise ValueError('Name is required.')
        aid = next_id(Actor, 'Actor_ID')
        with connection.cursor() as c:
            c.execute("INSERT INTO `actor` (Actor_ID,Name,DOB) VALUES (%s,%s,%s)",
                      [aid, name, dob or None])
        request.session['msg'] = f'Actor "{name}" added.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_actors')


@login_required_admin
def admin_actor_edit(request, actor_id):
    if request.method != 'POST':
        return redirect('admin_actors')
    try:
        name = request.POST.get('name', '').strip()
        dob  = request.POST.get('dob', '').strip()
        with connection.cursor() as c:
            c.execute("UPDATE `actor` SET Name=%s,DOB=%s WHERE Actor_ID=%s",
                      [name, dob or None, actor_id])
        request.session['msg'] = 'Actor updated.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_actors')


@login_required_admin
def admin_actor_delete(request, actor_id):
    if request.method != 'POST':
        return redirect('admin_actors')
    try:
        with connection.cursor() as c:
            c.execute("DELETE FROM `acts_in` WHERE Actor_ID=%s", [actor_id])
            c.execute("DELETE FROM `actor` WHERE Actor_ID=%s", [actor_id])
        request.session['msg'] = 'Actor deleted.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_actors')


# ─── ADMIN: DIRECTOR CRUD ────────────────────────────────────────────────────

@login_required_admin
def admin_directors(request):
    msg = request.session.pop('msg', None)
    msg_type = request.session.pop('msg_type', 'success')
    directors = Director.objects.all().order_by('Name')
    return render(request, 'ott_app/admin_directors.html', {
        'directors': directors, 'msg': msg, 'msg_type': msg_type,
    })


@login_required_admin
def admin_director_add(request):
    if request.method != 'POST':
        return redirect('admin_directors')
    try:
        name = request.POST.get('name', '').strip()
        dob  = request.POST.get('dob', '').strip()
        if not name:
            raise ValueError('Name is required.')
        did = next_id(Director, 'Director_ID')
        with connection.cursor() as c:
            c.execute("INSERT INTO `director` (Director_ID,Name,DOB) VALUES (%s,%s,%s)",
                      [did, name, dob or None])
        request.session['msg'] = f'Director "{name}" added.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_directors')


@login_required_admin
def admin_director_edit(request, director_id):
    if request.method != 'POST':
        return redirect('admin_directors')
    try:
        name = request.POST.get('name', '').strip()
        dob  = request.POST.get('dob', '').strip()
        with connection.cursor() as c:
            c.execute("UPDATE `director` SET Name=%s,DOB=%s WHERE Director_ID=%s",
                      [name, dob or None, director_id])
        request.session['msg'] = 'Director updated.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_directors')


@login_required_admin
def admin_director_delete(request, director_id):
    if request.method != 'POST':
        return redirect('admin_directors')
    try:
        with connection.cursor() as c:
            c.execute("DELETE FROM `directs` WHERE Director_ID=%s", [director_id])
            c.execute("DELETE FROM `director` WHERE Director_ID=%s", [director_id])
        request.session['msg'] = 'Director deleted.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_directors')


# ─── ADMIN: USER CRUD ────────────────────────────────────────────────────────

@login_required_admin
def admin_users(request):
    msg = request.session.pop('msg', None)
    msg_type = request.session.pop('msg_type', 'success')
    users = User.objects.all().order_by('User_ID')
    logins = {l.User_id: l for l in Login.objects.filter(Role='user')}
    user_data = [{'user': u, 'login': logins.get(u.User_ID)} for u in users]
    return render(request, 'ott_app/admin_users.html', {
        'user_data': user_data, 'msg': msg, 'msg_type': msg_type,
    })


@login_required_admin
def admin_user_add(request):
    if request.method != 'POST':
        return redirect('admin_users')
    try:
        name     = request.POST.get('name', '').strip()
        email    = request.POST.get('email', '').strip()
        phone    = request.POST.get('phone', '').strip()
        country  = request.POST.get('country', '').strip()
        dob      = request.POST.get('dob', '').strip()
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()
        if not all([name, email, username, password]):
            raise ValueError('Name, email, username and password are required.')
        if Login.objects.filter(Username=username).exists():
            raise ValueError(f'Username "{username}" already taken.')
        if User.objects.filter(Email=email).exists():
            raise ValueError('Email already in use.')
        uid = next_id(User, 'User_ID')
        lid = next_id(Login, 'Login_ID')
        with connection.cursor() as c:
            c.execute("INSERT INTO `user` (User_ID,Name,Email,Phone,Country,DOB) VALUES (%s,%s,%s,%s,%s,%s)",
                      [uid, name, email, phone or None, country or None, dob or None])
            c.execute("INSERT INTO `login` (Login_ID,User_ID,Username,Password,Role) VALUES (%s,%s,%s,%s,%s)",
                      [lid, uid, username, password, 'user'])
        request.session['msg'] = f'User "{name}" added.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_users')


@login_required_admin
def admin_user_edit(request, user_id):
    if request.method != 'POST':
        return redirect('admin_users')
    try:
        name     = request.POST.get('name', '').strip()
        email    = request.POST.get('email', '').strip()
        phone    = request.POST.get('phone', '').strip()
        country  = request.POST.get('country', '').strip()
        dob      = request.POST.get('dob', '').strip()
        password = request.POST.get('password', '').strip()
        with connection.cursor() as c:
            c.execute("UPDATE `user` SET Name=%s,Email=%s,Phone=%s,Country=%s,DOB=%s WHERE User_ID=%s",
                      [name, email, phone or None, country or None, dob or None, user_id])
            if password:
                c.execute("UPDATE `login` SET Password=%s WHERE User_ID=%s", [password, user_id])
        request.session['msg'] = f'User "{name}" updated.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_users')


@login_required_admin
def admin_user_delete(request, user_id):
    if request.method != 'POST':
        return redirect('admin_users')
    try:
        with connection.cursor() as c:
            c.execute("DELETE FROM `watches` WHERE User_ID=%s", [user_id])
            c.execute("DELETE FROM `payment` WHERE User_ID=%s", [user_id])
            c.execute("DELETE FROM `login` WHERE User_ID=%s", [user_id])
            c.execute("DELETE FROM `user` WHERE User_ID=%s", [user_id])
        request.session['msg'] = 'User deleted.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_users')


# ─── ADMIN: PLANS CRUD ───────────────────────────────────────────────────────

@login_required_admin
def admin_plans(request):
    msg = request.session.pop('msg', None)
    msg_type = request.session.pop('msg_type', 'success')
    plans = SubPlan.objects.all().order_by('Plan_ID')
    return render(request, 'ott_app/admin_plans.html', {
        'plans': plans, 'msg': msg, 'msg_type': msg_type,
    })


@login_required_admin
def admin_plan_add(request):
    if request.method != 'POST':
        return redirect('admin_plans')
    try:
        name     = request.POST.get('plan_name', '').strip()
        price    = float(request.POST.get('price', 0))
        duration = request.POST.get('duration', '').strip()
        quality  = request.POST.get('video_quality', '').strip()
        if not name:
            raise ValueError('Plan name is required.')
        pid = next_id(SubPlan, 'Plan_ID')
        with connection.cursor() as c:
            c.execute("INSERT INTO `sub_plan` (Plan_ID,Plan_Name,Price,Duration,Video_Quality) VALUES (%s,%s,%s,%s,%s)",
                      [pid, name, price, duration or None, quality or None])
        request.session['msg'] = f'Plan "{name}" added.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_plans')


@login_required_admin
def admin_plan_edit(request, plan_id):
    if request.method != 'POST':
        return redirect('admin_plans')
    try:
        name     = request.POST.get('plan_name', '').strip()
        price    = float(request.POST.get('price', 0))
        duration = request.POST.get('duration', '').strip()
        quality  = request.POST.get('video_quality', '').strip()
        with connection.cursor() as c:
            c.execute("UPDATE `sub_plan` SET Plan_Name=%s,Price=%s,Duration=%s,Video_Quality=%s WHERE Plan_ID=%s",
                      [name, price, duration or None, quality or None, plan_id])
        request.session['msg'] = f'Plan "{name}" updated.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_plans')


@login_required_admin
def admin_plan_delete(request, plan_id):
    if request.method != 'POST':
        return redirect('admin_plans')
    try:
        with connection.cursor() as c:
            c.execute("DELETE FROM `sub_plan` WHERE Plan_ID=%s", [plan_id])
        request.session['msg'] = 'Plan deleted.'
        request.session['msg_type'] = 'success'
    except Exception as e:
        request.session['msg'] = f'Error: {str(e)}'
        request.session['msg_type'] = 'error'
    return redirect('admin_plans')


# ─── ADMIN: PAYMENTS ─────────────────────────────────────────────────────────

@login_required_admin
def admin_payments(request):
    payments = Payment.objects.select_related('User', 'Plan').order_by('-Date')
    return render(request, 'ott_app/admin_payments.html', {'payments': payments})
