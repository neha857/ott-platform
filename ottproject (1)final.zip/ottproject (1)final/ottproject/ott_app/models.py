from django.db import models


class User(models.Model):
    User_ID = models.IntegerField(primary_key=True)
    Name = models.CharField(max_length=100, null=True)
    Email = models.CharField(max_length=100, null=True)
    Phone = models.CharField(max_length=15, null=True)
    Country = models.CharField(max_length=50, null=True)
    DOB = models.DateField(null=True)

    class Meta:
        db_table = 'user'
        managed = False


class Login(models.Model):
    Login_ID = models.IntegerField(primary_key=True)
    User = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, db_column='User_ID')
    Username = models.CharField(max_length=50, null=True)
    Password = models.CharField(max_length=50, null=True)
    Role = models.CharField(max_length=10, null=True)

    class Meta:
        db_table = 'login'
        managed = False


class Content(models.Model):
    Content_ID = models.IntegerField(primary_key=True)
    Title = models.CharField(max_length=255, null=True)
    Duration = models.CharField(max_length=50, null=True)
    Release_Country = models.CharField(max_length=50, null=True)
    Release_Year = models.IntegerField(null=True)
    Rating = models.DecimalField(max_digits=3, decimal_places=1, null=True)

    class Meta:
        db_table = 'content'
        managed = False


class Movie(models.Model):
    Content = models.OneToOneField(Content, primary_key=True, on_delete=models.CASCADE, db_column='Content_ID')
    Box_Office_Collection = models.CharField(max_length=50, null=True)

    class Meta:
        db_table = 'movie'
        managed = False


class Series(models.Model):
    Content = models.OneToOneField(Content, primary_key=True, on_delete=models.CASCADE, db_column='Content_ID')
    No_of_Seasons = models.IntegerField(null=True)

    class Meta:
        db_table = 'series'
        managed = False


class Episode(models.Model):
    Episode_ID = models.IntegerField(primary_key=True)
    Content = models.ForeignKey(Series, on_delete=models.CASCADE, null=True, db_column='Content_ID')
    Season_No = models.IntegerField(null=True)
    Title = models.CharField(max_length=255, null=True)
    Duration = models.CharField(max_length=50, null=True)
    Release_Date = models.DateField(null=True)

    class Meta:
        db_table = 'episode'
        managed = False


class Actor(models.Model):
    Actor_ID = models.IntegerField(primary_key=True)
    Name = models.CharField(max_length=100, null=True)
    DOB = models.DateField(null=True)

    class Meta:
        db_table = 'actor'
        managed = False


class ActsIn(models.Model):
    Content = models.ForeignKey(Content, on_delete=models.CASCADE, db_column='Content_ID', primary_key=True)
    Actor = models.ForeignKey(Actor, on_delete=models.CASCADE, db_column='Actor_ID')

    class Meta:
        db_table = 'acts_in'
        managed = False
        unique_together = (('Content', 'Actor'),)


class Director(models.Model):
    Director_ID = models.IntegerField(primary_key=True)
    Name = models.CharField(max_length=100, null=True)
    DOB = models.DateField(null=True)

    class Meta:
        db_table = 'director'
        managed = False


class Directs(models.Model):
    Content = models.ForeignKey(Content, on_delete=models.CASCADE, db_column='Content_ID', primary_key=True)
    Director = models.ForeignKey(Director, on_delete=models.CASCADE, db_column='Director_ID')

    class Meta:
        db_table = 'directs'
        managed = False
        unique_together = (('Content', 'Director'),)


class SubPlan(models.Model):
    Plan_ID = models.IntegerField(primary_key=True)
    Plan_Name = models.CharField(max_length=50, null=True)
    Price = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    Duration = models.CharField(max_length=50, null=True)
    Video_Quality = models.CharField(max_length=20, null=True)

    class Meta:
        db_table = 'sub_plan'
        managed = False


class Payment(models.Model):
    Payment_ID = models.IntegerField(primary_key=True)
    User = models.ForeignKey(User, on_delete=models.CASCADE, null=True, db_column='User_ID')
    Plan = models.ForeignKey(SubPlan, on_delete=models.CASCADE, null=True, db_column='Plan_ID')
    Amount = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    Date = models.DateField(null=True)
    Method = models.CharField(max_length=50, null=True)
    Status = models.CharField(max_length=20, null=True)

    class Meta:
        db_table = 'payment'
        managed = False


class Watches(models.Model):
    User = models.ForeignKey(User, on_delete=models.CASCADE, db_column='User_ID', primary_key=True)
    Content = models.ForeignKey(Content, on_delete=models.CASCADE, db_column='Content_ID')

    class Meta:
        db_table = 'watches'
        managed = False
        unique_together = (('User', 'Content'),)
