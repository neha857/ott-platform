from django.urls import path
from . import views

urlpatterns = [
    # Auth
    path('', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('signup/', views.signup_view, name='signup'),

    # User
    path('home/', views.user_home, name='user_home'),
    path('browse/', views.user_browse, name='user_browse'),
    path('browse/search-suggestions/', views.search_suggestions, name='search_suggestions'),
    path('content/<int:content_id>/', views.content_detail, name='content_detail'),
    path('profile/', views.user_profile, name='user_profile'),
    path('plans/', views.user_plans, name='user_plans'),
    path('plans/subscribe/', views.subscribe_plan, name='subscribe_plan'),

    # Admin — dashboard & payments (read-only)
    path('admin-panel/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-panel/payments/', views.admin_payments, name='admin_payments'),

    # Admin — Content CRUD
    path('admin-panel/content/', views.admin_content, name='admin_content'),
    path('admin-panel/content/add/', views.admin_content_add, name='admin_content_add'),
    path('admin-panel/content/<int:content_id>/edit/', views.admin_content_edit, name='admin_content_edit'),
    path('admin-panel/content/<int:content_id>/delete/', views.admin_content_delete, name='admin_content_delete'),

    # Admin — Episodes CRUD
    path('admin-panel/content/<int:content_id>/episodes/', views.admin_episodes, name='admin_episodes'),
    path('admin-panel/content/<int:content_id>/episodes/add/', views.admin_episode_add, name='admin_episode_add'),
    path('admin-panel/episodes/<int:episode_id>/delete/', views.admin_episode_delete, name='admin_episode_delete'),

    # Admin — Actor CRUD
    path('admin-panel/actors/', views.admin_actors, name='admin_actors'),
    path('admin-panel/actors/add/', views.admin_actor_add, name='admin_actor_add'),
    path('admin-panel/actors/<int:actor_id>/edit/', views.admin_actor_edit, name='admin_actor_edit'),
    path('admin-panel/actors/<int:actor_id>/delete/', views.admin_actor_delete, name='admin_actor_delete'),

    # Admin — Director CRUD
    path('admin-panel/directors/', views.admin_directors, name='admin_directors'),
    path('admin-panel/directors/add/', views.admin_director_add, name='admin_director_add'),
    path('admin-panel/directors/<int:director_id>/edit/', views.admin_director_edit, name='admin_director_edit'),
    path('admin-panel/directors/<int:director_id>/delete/', views.admin_director_delete, name='admin_director_delete'),

    # Admin — User CRUD
    path('admin-panel/users/', views.admin_users, name='admin_users'),
    path('admin-panel/users/add/', views.admin_user_add, name='admin_user_add'),
    path('admin-panel/users/<int:user_id>/edit/', views.admin_user_edit, name='admin_user_edit'),
    path('admin-panel/users/<int:user_id>/delete/', views.admin_user_delete, name='admin_user_delete'),

    # Admin — Plans CRUD
    path('admin-panel/plans/', views.admin_plans, name='admin_plans'),
    path('admin-panel/plans/add/', views.admin_plan_add, name='admin_plan_add'),
    path('admin-panel/plans/<int:plan_id>/edit/', views.admin_plan_edit, name='admin_plan_edit'),
    path('admin-panel/plans/<int:plan_id>/delete/', views.admin_plan_delete, name='admin_plan_delete'),
]
