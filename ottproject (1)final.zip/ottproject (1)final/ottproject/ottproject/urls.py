from django.urls import path, include

urlpatterns = [
    path('', include('ott_app.urls')),
]
