# StreamVault — OTT Django Web Application

A full-featured OTT platform web app built with Django, connected to your existing MySQL `ott` database.

---

## Project Structure

```
ottproject/
├── manage.py
├── requirements.txt
├── ottproject/
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
└── ott_app/
    ├── models.py       ← Maps to your existing DB tables (managed=False)
    ├── views.py        ← All page logic
    ├── urls.py         ← URL routing
    └── templates/
        └── ott_app/
            ├── base.html             ← Shared styles & layout
            ├── login.html            ← Login with User / Admin mode toggle
            ├── admin_base.html       ← Admin sidebar layout
            ├── user_home.html        ← User landing page
            ├── user_browse.html      ← Browse all content
            ├── content_detail.html   ← Movie / Series detail page
            ├── user_profile.html     ← Profile + payment history
            ├── user_plans.html       ← Subscription plans
            ├── admin_dashboard.html  ← Admin stats overview
            ├── admin_users.html      ← Manage users
            ├── admin_content.html    ← Manage content
            ├── admin_payments.html   ← Payment records
            ├── admin_plans.html      ← Subscription plans
            ├── admin_actors.html     ← Actor records
            └── admin_directors.html  ← Director records
```

---

## Setup Instructions

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

> If `mysqlclient` fails to install on Windows, try:
> ```bash
> pip install PyMySQL
> ```
> Then add to `ottproject/__init__.py`:
> ```python
> import pymysql
> pymysql.install_as_MySQLdb()
> ```

### 2. Configure your database

Open `ottproject/settings.py` and update the `DATABASES` block:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'ott',
        'USER': 'root',        # your MySQL username
        'PASSWORD': 'bhuri@1405',        # your MySQL password
        'HOST': 'localhost',
        'PORT': '3306',
    }
}
```

### 3. Create session table (required for login)

```bash
python manage.py createcachetable
python manage.py migrate --run-syncdb
```

> Since all models use `managed = False`, Django won't touch your existing tables.
> The `migrate` command only creates Django's internal session table.

### 4. Run the server

```bash
python manage.py runserver
```

Visit: **http://127.0.0.1:8000/**

---

## Login Credentials (from your database)

| Mode  | Username | Password  |
|-------|----------|-----------|
| User  | aditi    | user123   |
| User  | rahul    | user123   |
| User  | neha     | user123   |
| Admin | admin    | admin123  |

---

## Pages

### User Mode
| URL | Page |
|-----|------|
| `/` | Login |
| `/home/` | Home — browse featured content |
| `/browse/` | Browse all (filter by movie/series) |
| `/content/<id>/` | Content detail — cast, director, episodes |
| `/profile/` | Profile, watch history, payment history |
| `/plans/` | Subscription plans |

### Admin Mode
| URL | Page |
|-----|------|
| `/admin-panel/` | Dashboard with stats |
| `/admin-panel/users/` | All users |
| `/admin-panel/content/` | All content |
| `/admin-panel/payments/` | All payments |
| `/admin-panel/plans/` | Subscription plans |
| `/admin-panel/actors/` | Actors |
| `/admin-panel/directors/` | Directors |

---

## Notes

- All models use `managed = False` — Django reads but never modifies your table schema.
- Sessions use file-based storage (no extra DB table needed).
- Passwords in the demo DB are plain text matching the `login` table values.
