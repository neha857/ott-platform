# StreamVault — OTT Platform Web App (Django + MySQL)

A full-featured OTT platform management system built with Django, connected directly to your existing MySQL `ott` database.

---

## 📁 Project Structure

```
ott_platform/
├── manage.py
├── requirements.txt
├── ott_platform/          # Django project settings
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
└── core/                  # Main application
    ├── models.py          # ORM models (mapped to your MySQL tables)
    ├── views.py           # All view logic
    ├── urls.py            # URL routing
    └── templates/core/    # All HTML templates
        ├── base.html
        ├── login.html
        ├── register.html
        ├── user_dashboard.html
        ├── browse.html
        ├── search_actor.html
        ├── content_detail.html
        ├── top_rated.html
        ├── profile.html
        ├── admin_dashboard.html
        ├── admin_users.html
        ├── admin_content.html
        ├── admin_add_content.html
        ├── admin_add_actor.html
        ├── admin_add_director.html
        ├── admin_payments.html
        └── admin_sql.html
```

---

## ⚙️ Setup Instructions

### 1. Install Python dependencies

```bash
cd ott_platform
pip install -r requirements.txt
```

> If `mysqlclient` fails to install, try:
> - Windows: `pip install mysqlclient` (needs MySQL Connector C)
> - Or use PyMySQL instead: `pip install PyMySQL` and add to `ott_platform/__init__.py`:
>   ```python
>   import pymysql
>   pymysql.install_as_MySQLdb()
>   ```

### 2. Configure MySQL connection

Open `ott_platform/settings.py` and update:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'ott',           # your database name
        'USER': 'root',          # your MySQL username
        'PASSWORD': 'password',  # your MySQL password
        'HOST': 'localhost',
        'PORT': '3306',
    }
}
```

### 3. Set up Django sessions table (one-time)

Since `managed = False` is set for all OTT models (they already exist in MySQL), you only need to create the Django session table:

```bash
python manage.py migrate
```

### 4. Run the development server

```bash
python manage.py runserver
```

Visit: **http://127.0.0.1:8000**

---

## 🔐 Login Credentials

| Role  | Username | Password  |
|-------|----------|-----------|
| User  | aditi    | user123   |
| User  | rahul    | user123   |
| User  | neha     | user123   |
| Admin | admin    | admin123  |

---

## 🚀 Features

### User Mode
| Feature | Description |
|---------|-------------|
| **Register** | Create account → inserted into `user` + `login` tables, optional subscription to `payment` |
| **Browse** | Filter content by type, country, rating; full-text search on title/actor/director |
| **Search by Actor** | Dedicated page showing SQL JOIN query across `acts_in`, `actor`, `content` |
| **Content Detail** | Full info page with actors, directors, episodes (for series), box office |
| **Mark as Watched** | Adds record to `watches` table |
| **Top Rated** | Ranked list using GROUP BY + COUNT + ORDER BY |
| **My Profile** | Shows user details + full payment history |

### Admin Mode
| Feature | Description |
|---------|-------------|
| **Dashboard** | Stats: total users, movies, series, revenue; recent payments |
| **Add Content** | Insert new movie or series into `content` + `movie`/`series` + `acts_in`/`directs` |
| **Add Actor/Director** | Insert into `actor`/`director` tables |
| **Delete Content** | Cascading delete across all related tables |
| **Manage Users** | View all users with plan info; delete users (cascades to payments, watch history) |
| **Payments View** | Full payment history with per-plan revenue stats |
| **SQL Explorer** | Run custom SELECT queries live; 5 preset analytical queries built-in |

---

## 🗄️ SQL Queries Used

The app uses raw SQL (via `connection.cursor()`) to demonstrate real DBMS operations:

- **JOINs**: Browse page joins `content`, `acts_in`, `actor`, `directs`, `director`, `movie`, `series`
- **GROUP BY + GROUP_CONCAT**: Aggregating actor/director names per content
- **Subqueries**: Latest plan per user in admin users view
- **LIKE with wildcards**: Search by actor name (`WHERE a.Name LIKE %s`)
- **COUNT + ORDER BY**: Top-rated page ranks by watch count
- **Cascading DELETE**: Manual multi-table delete for data integrity
- **INSERT across multiple tables**: Registration inserts into `user`, `login`, `payment` in sequence

---

## 🛠️ Troubleshooting

**`no such table: django_session`** → Run `python manage.py migrate`

**MySQL connection error** → Check username/password in `settings.py`; ensure MySQL is running

**`mysqlclient` install error on Windows** → Use PyMySQL (see setup step 1)

**Static files not loading** → For production, run `python manage.py collectstatic`
