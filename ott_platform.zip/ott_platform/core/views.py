from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db import connection
from django.utils import timezone
from .models import (
    User, Login, Content, Movie, Series, Actor, Director,
    ActsIn, Directs, Watches, SubPlan, Payment, Episode
)
import datetime


# ─── Helpers ──────────────────────────────────────────────────────────────────

def get_current_user(request):
    uid = request.session.get('user_id')
    role = request.session.get('role')
    return uid, role


def login_required_user(view_fn):
    def wrapper(request, *args, **kwargs):
        uid, role = get_current_user(request)
        if not uid or role != 'user':
            messages.error(request, 'Please login first.')
            return redirect('login')
        return view_fn(request, *args, **kwargs)
    wrapper.__name__ = view_fn.__name__
    return wrapper


def login_required_admin(view_fn):
    def wrapper(request, *args, **kwargs):
        uid, role = get_current_user(request)
        if role != 'admin':
            messages.error(request, 'Admin access required.')
            return redirect('login')
        return view_fn(request, *args, **kwargs)
    wrapper.__name__ = view_fn.__name__
    return wrapper


# ─── Auth ─────────────────────────────────────────────────────────────────────

def home(request):
    uid, role = get_current_user(request)
    if uid and role == 'user':
        return redirect('user_dashboard')
    if role == 'admin':
        return redirect('admin_dashboard')
    return redirect('login')


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()
        try:
            login_obj = Login.objects.get(username=username, password=password)
            request.session['role'] = login_obj.role
            request.session['username'] = login_obj.username
            if login_obj.user:
                request.session['user_id'] = login_obj.user.user_id
                request.session['user_name'] = login_obj.user.name
            else:
                request.session['user_id'] = None
                request.session['user_name'] = 'Admin'
            if login_obj.role == 'admin':
                return redirect('admin_dashboard')
            return redirect('user_dashboard')
        except Login.DoesNotExist:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'core/login.html')


def register_view(request):
    plans = SubPlan.objects.all()
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        email = request.POST.get('email', '').strip()
        phone = request.POST.get('phone', '').strip()
        country = request.POST.get('country', '').strip()
        dob = request.POST.get('dob', '').strip()
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()
        plan_id = request.POST.get('plan_id', '').strip()

        # Check username uniqueness
        if Login.objects.filter(username=username).exists():
            messages.error(request, 'Username already taken.')
            return render(request, 'core/register.html', {'plans': plans})

        # Insert user
        with connection.cursor() as cursor:
            cursor.execute(
                "INSERT INTO user (Name, Email, Phone, Country, DOB) VALUES (%s,%s,%s,%s,%s)",
                [name, email, phone, country, dob]
            )
            user_id = cursor.lastrowid

            # Insert login
            cursor.execute(
                "INSERT INTO login (User_ID, Username, Password, Role) VALUES (%s,%s,%s,'user')",
                [user_id, username, password]
            )

            # Insert payment if plan selected
            if plan_id:
                plan = SubPlan.objects.get(plan_id=plan_id)
                cursor.execute(
                    "INSERT INTO payment (User_ID, Plan_ID, Amount, Date, Method, Status) VALUES (%s,%s,%s,%s,'UPI','Success')",
                    [user_id, plan_id, plan.price, datetime.date.today()]
                )

        messages.success(request, 'Account created! Please login.')
        return redirect('login')
    return render(request, 'core/register.html', {'plans': plans})


def logout_view(request):
    request.session.flush()
    return redirect('login')


# ─── User Dashboard ───────────────────────────────────────────────────────────

@login_required_user
def user_dashboard(request):
    uid = request.session['user_id']
    user = User.objects.get(user_id=uid)

    # Watch history with SQL
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT c.Content_ID, c.Title, c.Rating, c.Release_Year,
                   c.Duration, c.Release_Country
            FROM watches w
            JOIN content c ON w.Content_ID = c.Content_ID
            WHERE w.User_ID = %s
        """, [uid])
        rows = cursor.fetchall()
        watch_history = [
            {'content_id': r[0], 'title': r[1], 'rating': r[2],
             'year': r[3], 'duration': r[4], 'country': r[5]}
            for r in rows
        ]

    # All content
    all_content = Content.objects.all().order_by('-rating')

    # Latest payment
    try:
        payment = Payment.objects.filter(user_id=uid).latest('date')
    except Payment.DoesNotExist:
        payment = None

    return render(request, 'core/user_dashboard.html', {
        'user': user,
        'watch_history': watch_history,
        'all_content': all_content,
        'payment': payment,
    })


@login_required_user
def browse_content(request):
    uid = request.session['user_id']
    query = request.GET.get('q', '').strip()
    filter_type = request.GET.get('type', '').strip()
    filter_country = request.GET.get('country', '').strip()
    min_rating = request.GET.get('min_rating', '').strip()

    sql = """
        SELECT c.Content_ID, c.Title, c.Duration, c.Release_Country,
               c.Release_Year, c.Rating,
               GROUP_CONCAT(DISTINCT a.Name ORDER BY a.Name SEPARATOR ', ') AS actors,
               GROUP_CONCAT(DISTINCT d.Name ORDER BY d.Name SEPARATOR ', ') AS directors,
               CASE WHEN m.Content_ID IS NOT NULL THEN 'Movie'
                    WHEN s.Content_ID IS NOT NULL THEN 'Series'
                    ELSE 'Unknown' END AS content_type
        FROM content c
        LEFT JOIN acts_in ai ON c.Content_ID = ai.Content_ID
        LEFT JOIN actor a ON ai.Actor_ID = a.Actor_ID
        LEFT JOIN directs di ON c.Content_ID = di.Content_ID
        LEFT JOIN director d ON di.Director_ID = d.Director_ID
        LEFT JOIN movie m ON c.Content_ID = m.Content_ID
        LEFT JOIN series s ON c.Content_ID = s.Content_ID
        WHERE 1=1
    """
    params = []

    if query:
        sql += " AND (c.Title LIKE %s OR a.Name LIKE %s OR d.Name LIKE %s)"
        params += [f'%{query}%', f'%{query}%', f'%{query}%']
    if filter_country:
        sql += " AND c.Release_Country = %s"
        params.append(filter_country)
    if min_rating:
        sql += " AND c.Rating >= %s"
        params.append(min_rating)

    sql += " GROUP BY c.Content_ID"

    if filter_type == 'Movie':
        sql += " HAVING content_type = 'Movie'"
    elif filter_type == 'Series':
        sql += " HAVING content_type = 'Series'"

    sql += " ORDER BY c.Rating DESC"

    with connection.cursor() as cursor:
        cursor.execute(sql, params)
        rows = cursor.fetchall()

    content_list = [
        {
            'content_id': r[0], 'title': r[1], 'duration': r[2],
            'country': r[3], 'year': r[4], 'rating': r[5],
            'actors': r[6] or 'N/A', 'directors': r[7] or 'N/A',
            'content_type': r[8],
        }
        for r in rows
    ]

    # Watched IDs
    watched_ids = set(Watches.objects.filter(user_id=uid).values_list('content_id', flat=True))

    return render(request, 'core/browse.html', {
        'content_list': content_list,
        'query': query,
        'filter_type': filter_type,
        'filter_country': filter_country,
        'min_rating': min_rating,
        'watched_ids': watched_ids,
        'sql_used': sql,
        'params_used': params,
    })


@login_required_user
def search_by_actor(request):
    actor_name = request.GET.get('actor', '').strip()
    results = []
    sql_query = ""
    if actor_name:
        sql_query = """
            SELECT c.Content_ID, c.Title, c.Rating, c.Release_Year,
                   a.Name AS actor_name, a.DOB,
                   CASE WHEN m.Content_ID IS NOT NULL THEN 'Movie'
                        WHEN s.Content_ID IS NOT NULL THEN 'Series'
                        ELSE 'Unknown' END AS content_type
            FROM content c
            JOIN acts_in ai ON c.Content_ID = ai.Content_ID
            JOIN actor a ON ai.Actor_ID = a.Actor_ID
            LEFT JOIN movie m ON c.Content_ID = m.Content_ID
            LEFT JOIN series s ON c.Content_ID = s.Content_ID
            WHERE a.Name LIKE %s
            ORDER BY c.Rating DESC
        """
        with connection.cursor() as cursor:
            cursor.execute(sql_query, [f'%{actor_name}%'])
            rows = cursor.fetchall()
        results = [
            {'content_id': r[0], 'title': r[1], 'rating': r[2],
             'year': r[3], 'actor': r[4], 'actor_dob': r[5], 'content_type': r[6]}
            for r in rows
        ]
    actors = Actor.objects.all()
    return render(request, 'core/search_actor.html', {
        'results': results,
        'actor_name': actor_name,
        'actors': actors,
        'sql_query': sql_query,
    })


@login_required_user
def content_detail(request, content_id):
    uid = request.session['user_id']
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT c.Content_ID, c.Title, c.Duration, c.Release_Country,
                   c.Release_Year, c.Rating,
                   GROUP_CONCAT(DISTINCT a.Name SEPARATOR ', ') AS actors,
                   GROUP_CONCAT(DISTINCT d.Name SEPARATOR ', ') AS directors,
                   m.Box_Office_Collection,
                   s.No_of_Seasons,
                   CASE WHEN m.Content_ID IS NOT NULL THEN 'Movie'
                        WHEN s.Content_ID IS NOT NULL THEN 'Series' ELSE 'Unknown' END
            FROM content c
            LEFT JOIN acts_in ai ON c.Content_ID = ai.Content_ID
            LEFT JOIN actor a ON ai.Actor_ID = a.Actor_ID
            LEFT JOIN directs di ON c.Content_ID = di.Content_ID
            LEFT JOIN director d ON di.Director_ID = d.Director_ID
            LEFT JOIN movie m ON c.Content_ID = m.Content_ID
            LEFT JOIN series s ON c.Content_ID = s.Content_ID
            WHERE c.Content_ID = %s
            GROUP BY c.Content_ID
        """, [content_id])
        row = cursor.fetchone()

    if not row:
        messages.error(request, 'Content not found.')
        return redirect('browse_content')

    content = {
        'content_id': row[0], 'title': row[1], 'duration': row[2],
        'country': row[3], 'year': row[4], 'rating': row[5],
        'actors': row[6] or 'N/A', 'directors': row[7] or 'N/A',
        'box_office': row[8], 'seasons': row[9], 'content_type': row[10],
    }

    # Episodes if series
    episodes = []
    if content['content_type'] == 'Series':
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT Episode_ID, Season_No, Title, Duration, Release_Date
                FROM episode WHERE Content_ID = %s ORDER BY Season_No, Episode_ID
            """, [content_id])
            episodes = cursor.fetchall()

    is_watched = Watches.objects.filter(user_id=uid, content_id=content_id).exists()
    return render(request, 'core/content_detail.html', {
        'content': content,
        'episodes': episodes,
        'is_watched': is_watched,
    })


@login_required_user
def mark_watched(request, content_id):
    uid = request.session['user_id']
    if not Watches.objects.filter(user_id=uid, content_id=content_id).exists():
        with connection.cursor() as cursor:
            cursor.execute(
                "INSERT INTO watches (User_ID, Content_ID) VALUES (%s, %s)",
                [uid, content_id]
            )
        messages.success(request, 'Added to your watch history!')
    else:
        messages.info(request, 'Already in watch history.')
    return redirect('content_detail', content_id=content_id)


@login_required_user
def top_rated(request):
    """Show top-rated content using SQL aggregate query"""
    sql = """
        SELECT c.Content_ID, c.Title, c.Rating, c.Release_Year,
               COUNT(w.User_ID) AS watch_count,
               CASE WHEN m.Content_ID IS NOT NULL THEN 'Movie'
                    WHEN s.Content_ID IS NOT NULL THEN 'Series' ELSE 'Unknown' END AS ctype
        FROM content c
        LEFT JOIN watches w ON c.Content_ID = w.Content_ID
        LEFT JOIN movie m ON c.Content_ID = m.Content_ID
        LEFT JOIN series s ON c.Content_ID = s.Content_ID
        GROUP BY c.Content_ID
        ORDER BY c.Rating DESC, watch_count DESC
    """
    with connection.cursor() as cursor:
        cursor.execute(sql)
        rows = cursor.fetchall()
    content_list = [
        {'content_id': r[0], 'title': r[1], 'rating': r[2],
         'year': r[3], 'watch_count': r[4], 'ctype': r[5]}
        for r in rows
    ]
    return render(request, 'core/top_rated.html', {'content_list': content_list, 'sql': sql})


@login_required_user
def my_profile(request):
    uid = request.session['user_id']
    user = User.objects.get(user_id=uid)
    payments = Payment.objects.filter(user_id=uid).select_related('plan').order_by('-date')
    return render(request, 'core/profile.html', {'user': user, 'payments': payments})


# ─── Admin Views ──────────────────────────────────────────────────────────────

@login_required_admin
def admin_dashboard(request):
    with connection.cursor() as cursor:
        cursor.execute("SELECT COUNT(*) FROM user")
        total_users = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM content")
        total_content = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM movie")
        total_movies = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM series")
        total_series = cursor.fetchone()[0]
        cursor.execute("SELECT SUM(Amount) FROM payment WHERE Status='Success'")
        total_revenue = cursor.fetchone()[0] or 0
        cursor.execute("""
            SELECT u.Name, c.Title, p.Amount, p.Date, p.Status, sp.Plan_Name
            FROM payment p
            JOIN user u ON p.User_ID = u.User_ID
            JOIN sub_plan sp ON p.Plan_ID = sp.Plan_ID
            LEFT JOIN content c ON p.Plan_ID = c.Content_ID
            ORDER BY p.Date DESC LIMIT 5
        """)
        # Simple recent payments
        cursor.execute("""
            SELECT p.Payment_ID, u.Name, sp.Plan_Name, p.Amount, p.Date, p.Status
            FROM payment p
            JOIN user u ON p.User_ID = u.User_ID
            JOIN sub_plan sp ON p.Plan_ID = sp.Plan_ID
            ORDER BY p.Date DESC LIMIT 5
        """)
        recent_payments = cursor.fetchall()

    return render(request, 'core/admin_dashboard.html', {
        'total_users': total_users,
        'total_content': total_content,
        'total_movies': total_movies,
        'total_series': total_series,
        'total_revenue': total_revenue,
        'recent_payments': recent_payments,
    })


@login_required_admin
def admin_users(request):
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT u.User_ID, u.Name, u.Email, u.Phone, u.Country, u.DOB,
                   l.Username,
                   (SELECT sp.Plan_Name FROM payment p JOIN sub_plan sp ON p.Plan_ID=sp.Plan_ID
                    WHERE p.User_ID=u.User_ID AND p.Status='Success' ORDER BY p.Date DESC LIMIT 1) AS plan
            FROM user u
            LEFT JOIN login l ON u.User_ID = l.User_ID
            ORDER BY u.User_ID
        """)
        rows = cursor.fetchall()
    users = [
        {'user_id': r[0], 'name': r[1], 'email': r[2], 'phone': r[3],
         'country': r[4], 'dob': r[5], 'username': r[6], 'plan': r[7] or 'None'}
        for r in rows
    ]
    return render(request, 'core/admin_users.html', {'users': users})


@login_required_admin
def admin_delete_user(request, user_id):
    if request.method == 'POST':
        with connection.cursor() as cursor:
            cursor.execute("DELETE FROM watches WHERE User_ID=%s", [user_id])
            cursor.execute("DELETE FROM payment WHERE User_ID=%s", [user_id])
            cursor.execute("DELETE FROM login WHERE User_ID=%s", [user_id])
            cursor.execute("DELETE FROM user WHERE User_ID=%s", [user_id])
        messages.success(request, 'User deleted successfully.')
    return redirect('admin_users')


@login_required_admin
def admin_content(request):
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT c.Content_ID, c.Title, c.Duration, c.Release_Country, c.Release_Year, c.Rating,
                   CASE WHEN m.Content_ID IS NOT NULL THEN 'Movie'
                        WHEN s.Content_ID IS NOT NULL THEN 'Series' ELSE 'Unknown' END AS ctype,
                   GROUP_CONCAT(DISTINCT a.Name SEPARATOR ', ') AS actors,
                   GROUP_CONCAT(DISTINCT d.Name SEPARATOR ', ') AS directors
            FROM content c
            LEFT JOIN movie m ON c.Content_ID = m.Content_ID
            LEFT JOIN series s ON c.Content_ID = s.Content_ID
            LEFT JOIN acts_in ai ON c.Content_ID = ai.Content_ID
            LEFT JOIN actor a ON ai.Actor_ID = a.Actor_ID
            LEFT JOIN directs di ON c.Content_ID = di.Content_ID
            LEFT JOIN director d ON di.Director_ID = d.Director_ID
            GROUP BY c.Content_ID
            ORDER BY c.Content_ID
        """)
        rows = cursor.fetchall()
    content_list = [
        {'content_id': r[0], 'title': r[1], 'duration': r[2], 'country': r[3],
         'year': r[4], 'rating': r[5], 'ctype': r[6], 'actors': r[7] or '-', 'directors': r[8] or '-'}
        for r in rows
    ]
    actors = Actor.objects.all()
    directors = Director.objects.all()
    return render(request, 'core/admin_content.html', {
        'content_list': content_list,
        'actors': actors,
        'directors': directors,
    })


@login_required_admin
def admin_add_content(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        duration = request.POST.get('duration')
        country = request.POST.get('release_country')
        year = request.POST.get('release_year')
        rating = request.POST.get('rating')
        content_type = request.POST.get('content_type')
        actor_ids = request.POST.getlist('actor_ids')
        director_ids = request.POST.getlist('director_ids')

        with connection.cursor() as cursor:
            cursor.execute(
                "INSERT INTO content (Title, Duration, Release_Country, Release_Year, Rating) VALUES (%s,%s,%s,%s,%s)",
                [title, duration, country, year, rating]
            )
            content_id = cursor.lastrowid

            if content_type == 'Movie':
                box_office = request.POST.get('box_office', '')
                cursor.execute("INSERT INTO movie (Content_ID, Box_Office_Collection) VALUES (%s,%s)",
                               [content_id, box_office])
            elif content_type == 'Series':
                seasons = request.POST.get('no_of_seasons', 1)
                cursor.execute("INSERT INTO series (Content_ID, No_of_Seasons) VALUES (%s,%s)",
                               [content_id, seasons])

            for aid in actor_ids:
                cursor.execute("INSERT INTO acts_in (Content_ID, Actor_ID) VALUES (%s,%s)", [content_id, aid])
            for did in director_ids:
                cursor.execute("INSERT INTO directs (Content_ID, Director_ID) VALUES (%s,%s)", [content_id, did])

        messages.success(request, f'"{title}" added successfully!')
        return redirect('admin_content')

    actors = Actor.objects.all()
    directors = Director.objects.all()
    return render(request, 'core/admin_add_content.html', {'actors': actors, 'directors': directors})


@login_required_admin
def admin_delete_content(request, content_id):
    if request.method == 'POST':
        with connection.cursor() as cursor:
            cursor.execute("DELETE FROM watches WHERE Content_ID=%s", [content_id])
            cursor.execute("DELETE FROM acts_in WHERE Content_ID=%s", [content_id])
            cursor.execute("DELETE FROM directs WHERE Content_ID=%s", [content_id])
            cursor.execute("DELETE FROM episode WHERE Content_ID=%s", [content_id])
            cursor.execute("DELETE FROM movie WHERE Content_ID=%s", [content_id])
            cursor.execute("DELETE FROM series WHERE Content_ID=%s", [content_id])
            cursor.execute("DELETE FROM content WHERE Content_ID=%s", [content_id])
        messages.success(request, 'Content deleted.')
    return redirect('admin_content')


@login_required_admin
def admin_add_actor(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        dob = request.POST.get('dob')
        with connection.cursor() as cursor:
            cursor.execute("INSERT INTO actor (Name, DOB) VALUES (%s,%s)", [name, dob])
        messages.success(request, f'Actor "{name}" added.')
        return redirect('admin_content')
    return render(request, 'core/admin_add_actor.html')


@login_required_admin
def admin_add_director(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        dob = request.POST.get('dob')
        with connection.cursor() as cursor:
            cursor.execute("INSERT INTO director (Name, DOB) VALUES (%s,%s)", [name, dob])
        messages.success(request, f'Director "{name}" added.')
        return redirect('admin_content')
    return render(request, 'core/admin_add_director.html')


@login_required_admin
def admin_payments(request):
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT p.Payment_ID, u.Name, sp.Plan_Name, p.Amount, p.Date, p.Method, p.Status
            FROM payment p
            JOIN user u ON p.User_ID = u.User_ID
            JOIN sub_plan sp ON p.Plan_ID = sp.Plan_ID
            ORDER BY p.Date DESC
        """)
        rows = cursor.fetchall()
    payments = [
        {'pid': r[0], 'user': r[1], 'plan': r[2], 'amount': r[3],
         'date': r[4], 'method': r[5], 'status': r[6]}
        for r in rows
    ]
    # Revenue by plan
    with connection.cursor() as cursor:
        cursor.execute("""
            SELECT sp.Plan_Name, COUNT(*) AS subs, SUM(p.Amount) AS revenue
            FROM payment p JOIN sub_plan sp ON p.Plan_ID=sp.Plan_ID
            WHERE p.Status='Success'
            GROUP BY sp.Plan_ID ORDER BY revenue DESC
        """)
        plan_stats = cursor.fetchall()

    return render(request, 'core/admin_payments.html', {
        'payments': payments,
        'plan_stats': plan_stats,
    })


@login_required_admin
def admin_sql_explorer(request):
    """Run custom SQL queries (SELECT only for safety)"""
    result = None
    columns = []
    error = None
    sql = request.POST.get('sql', '').strip()

    PRESET_QUERIES = {
        'top_content': "SELECT c.Title, c.Rating, COUNT(w.User_ID) AS Watchers FROM content c LEFT JOIN watches w ON c.Content_ID=w.Content_ID GROUP BY c.Content_ID ORDER BY c.Rating DESC",
        'user_plans': "SELECT u.Name, sp.Plan_Name, p.Amount, p.Status FROM payment p JOIN user u ON p.User_ID=u.User_ID JOIN sub_plan sp ON p.Plan_ID=sp.Plan_ID",
        'actor_content': "SELECT a.Name AS Actor, c.Title, c.Rating FROM acts_in ai JOIN actor a ON ai.Actor_ID=a.Actor_ID JOIN content c ON ai.Content_ID=c.Content_ID ORDER BY a.Name",
        'director_content': "SELECT d.Name AS Director, GROUP_CONCAT(c.Title SEPARATOR ', ') AS Titles FROM directs di JOIN director d ON di.Director_ID=d.Director_ID JOIN content c ON di.Content_ID=c.Content_ID GROUP BY d.Director_ID",
        'revenue': "SELECT sp.Plan_Name, COUNT(*) AS Subscribers, SUM(p.Amount) AS Revenue FROM payment p JOIN sub_plan sp ON p.Plan_ID=sp.Plan_ID WHERE p.Status='Success' GROUP BY sp.Plan_ID ORDER BY Revenue DESC",
    }

    if request.method == 'POST' and sql:
        if not sql.lower().strip().startswith('select'):
            error = 'Only SELECT queries are allowed in the explorer.'
        else:
            try:
                with connection.cursor() as cursor:
                    cursor.execute(sql)
                    columns = [col[0] for col in cursor.description]
                    result = cursor.fetchall()
            except Exception as e:
                error = str(e)

    return render(request, 'core/admin_sql.html', {
        'sql': sql,
        'result': result,
        'columns': columns,
        'error': error,
        'preset_queries': PRESET_QUERIES,
    })
