from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),

    # User
    path('dashboard/', views.user_dashboard, name='user_dashboard'),
    path('browse/', views.browse_content, name='browse_content'),
    path('search/actor/', views.search_by_actor, name='search_by_actor'),
    path('content/<int:content_id>/', views.content_detail, name='content_detail'),
    path('content/<int:content_id>/watch/', views.mark_watched, name='mark_watched'),
    path('top-rated/', views.top_rated, name='top_rated'),
    path('profile/', views.my_profile, name='my_profile'),

    # Admin
    path('admin-panel/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-panel/users/', views.admin_users, name='admin_users'),
    path('admin-panel/users/<int:user_id>/delete/', views.admin_delete_user, name='admin_delete_user'),
    path('admin-panel/content/', views.admin_content, name='admin_content'),
    path('admin-panel/content/add/', views.admin_add_content, name='admin_add_content'),
    path('admin-panel/content/<int:content_id>/delete/', views.admin_delete_content, name='admin_delete_content'),
    path('admin-panel/actor/add/', views.admin_add_actor, name='admin_add_actor'),
    path('admin-panel/director/add/', views.admin_add_director, name='admin_add_director'),
    path('admin-panel/payments/', views.admin_payments, name='admin_payments'),
    path('admin-panel/sql/', views.admin_sql_explorer, name='admin_sql'),
]
