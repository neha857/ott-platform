from django.db import models


class User(models.Model):
    user_id = models.AutoField(primary_key=True, db_column='User_ID')
    name = models.CharField(max_length=100, null=True, blank=True, db_column='Name')
    email = models.CharField(max_length=100, null=True, blank=True, db_column='Email')
    phone = models.CharField(max_length=15, null=True, blank=True, db_column='Phone')
    country = models.CharField(max_length=50, null=True, blank=True, db_column='Country')
    dob = models.DateField(null=True, blank=True, db_column='DOB')

    class Meta:
        db_table = 'user'
        managed = False


class Login(models.Model):
    login_id = models.AutoField(primary_key=True, db_column='Login_ID')
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, db_column='User_ID')
    username = models.CharField(max_length=50, null=True, blank=True, db_column='Username')
    password = models.CharField(max_length=50, null=True, blank=True, db_column='Password')
    role = models.CharField(max_length=10, null=True, blank=True, db_column='Role')

    class Meta:
        db_table = 'login'
        managed = False


class SubPlan(models.Model):
    plan_id = models.AutoField(primary_key=True, db_column='Plan_ID')
    plan_name = models.CharField(max_length=50, null=True, blank=True, db_column='Plan_Name')
    price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, db_column='Price')
    duration = models.CharField(max_length=50, null=True, blank=True, db_column='Duration')
    video_quality = models.CharField(max_length=20, null=True, blank=True, db_column='Video_Quality')

    class Meta:
        db_table = 'sub_plan'
        managed = False

    def __str__(self):
        return self.plan_name or ''


class Payment(models.Model):
    payment_id = models.AutoField(primary_key=True, db_column='Payment_ID')
    user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, db_column='User_ID')
    plan = models.ForeignKey(SubPlan, null=True, blank=True, on_delete=models.SET_NULL, db_column='Plan_ID')
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, db_column='Amount')
    date = models.DateField(null=True, blank=True, db_column='Date')
    method = models.CharField(max_length=50, null=True, blank=True, db_column='Method')
    status = models.CharField(max_length=20, null=True, blank=True, db_column='Status')

    class Meta:
        db_table = 'payment'
        managed = False


class Content(models.Model):
    content_id = models.AutoField(primary_key=True, db_column='Content_ID')
    title = models.CharField(max_length=255, null=True, blank=True, db_column='Title')
    duration = models.CharField(max_length=50, null=True, blank=True, db_column='Duration')
    release_country = models.CharField(max_length=50, null=True, blank=True, db_column='Release_Country')
    release_year = models.IntegerField(null=True, blank=True, db_column='Release_Year')
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True, blank=True, db_column='Rating')

    class Meta:
        db_table = 'content'
        managed = False

    def __str__(self):
        return self.title or ''


class Movie(models.Model):
    content = models.OneToOneField(Content, primary_key=True, on_delete=models.CASCADE, db_column='Content_ID')
    box_office_collection = models.CharField(max_length=50, null=True, blank=True, db_column='Box_Office_Collection')

    class Meta:
        db_table = 'movie'
        managed = False


class Series(models.Model):
    content = models.OneToOneField(Content, primary_key=True, on_delete=models.CASCADE, db_column='Content_ID')
    no_of_seasons = models.IntegerField(null=True, blank=True, db_column='No_of_Seasons')

    class Meta:
        db_table = 'series'
        managed = False


class Episode(models.Model):
    episode_id = models.AutoField(primary_key=True, db_column='Episode_ID')
    content = models.ForeignKey(Series, null=True, blank=True, on_delete=models.SET_NULL, db_column='Content_ID')
    season_no = models.IntegerField(null=True, blank=True, db_column='Season_No')
    title = models.CharField(max_length=255, null=True, blank=True, db_column='Title')
    duration = models.CharField(max_length=50, null=True, blank=True, db_column='Duration')
    release_date = models.DateField(null=True, blank=True, db_column='Release_Date')

    class Meta:
        db_table = 'episode'
        managed = False


class Actor(models.Model):
    actor_id = models.AutoField(primary_key=True, db_column='Actor_ID')
    name = models.CharField(max_length=100, null=True, blank=True, db_column='Name')
    dob = models.DateField(null=True, blank=True, db_column='DOB')

    class Meta:
        db_table = 'actor'
        managed = False

    def __str__(self):
        return self.name or ''


class Director(models.Model):
    director_id = models.AutoField(primary_key=True, db_column='Director_ID')
    name = models.CharField(max_length=100, null=True, blank=True, db_column='Name')
    dob = models.DateField(null=True, blank=True, db_column='DOB')

    class Meta:
        db_table = 'director'
        managed = False

    def __str__(self):
        return self.name or ''


class ActsIn(models.Model):
    content = models.ForeignKey(Content, on_delete=models.CASCADE, db_column='Content_ID')
    actor = models.ForeignKey(Actor, on_delete=models.CASCADE, db_column='Actor_ID')

    class Meta:
        db_table = 'acts_in'
        managed = False
        unique_together = (('content', 'actor'),)


class Directs(models.Model):
    content = models.ForeignKey(Content, on_delete=models.CASCADE, db_column='Content_ID')
    director = models.ForeignKey(Director, on_delete=models.CASCADE, db_column='Director_ID')

    class Meta:
        db_table = 'directs'
        managed = False
        unique_together = (('content', 'director'),)


class Watches(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, db_column='User_ID')
    content = models.ForeignKey(Content, on_delete=models.CASCADE, db_column='Content_ID')

    class Meta:
        db_table = 'watches'
        managed = False
        unique_together = (('user', 'content'),)
